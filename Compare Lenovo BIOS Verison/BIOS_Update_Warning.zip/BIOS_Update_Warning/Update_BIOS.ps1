﻿$Get_Current_Model = ((gwmi win32_computersystem).Model).Substring(0,4)
$BIOS_Update_Folder = "C:\windows\Temp\BIOSUpdate_$Get_Current_Model"
$User_Continue_Process_File = "$BIOS_Update_Folder\BIOS_Update_Continue.txt"
$Extract_Folder_Path = "$BIOS_Update_Folder\BIOS_Extract"
$WPF_Warning_Export_Folder = "$BIOS_Update_Folder\WPF_Warning"
$Log_File = "$env:SystemDrive\Windows\Debug\Remediate_Update_BIOS_$Get_Current_Model.log"

If(!(test-path $Log_File)){new-item $Log_File -type file -force}
If(!(test-path $Extract_Folder_Path)){new-item $Extract_Folder_Path -type Directory -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)		
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"		
		write-host  "$MyDate - $Message_Type : $Message"		
	}
	

# Si l'utlisateur a cliqué sur le Suivant final
If(test-path $User_Continue_Process_File)
	{							
		Write_Log -Message_Type "INFO" -Message "The user validate the update process"																		
	
		# On arrête Bitlocker
		Write_Log -Message_Type "INFO" -Message "Stopping Bitlocker"																
		
		$Check_Bitlocker_Status = Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object -Property ProtectionStatus
		If ($Check_Bitlocker_Status.ProtectionStatus -eq "On") 
			{
				Try
					{
						# Bitlocker sera démarré au prochain redémarrage
						Suspend-BitLocker -MountPoint $env:SystemDrive  -RebootCount 1 | out-null
						$Suspend_Bitlocker_Success = $True			
						Write_Log -Message_Type "SUCCESS" -Message "Stopping Bitlocker"
						Write_Log -Message_Type "SUCCESS" -Message "Bitlocker will be anabled again at next reboot"																														
					}
				Catch
					{
						Write_Log -Message_Type "ERROR" -Message "Stopping Bitlocker"	
						Break
					}
			}	
		Else
			{
				$Suspend_Bitlocker_Success = $True			
				Write_Log -Message_Type "SUCCESS" -Message "Bitlocker not enabled"						
			}
						
		# Si Bitlocker a été arrête avec succès, on met à jour le BIOS
		If($Suspend_Bitlocker_Success -eq $True)
			{
				# BIOS Update installer
				$WINUTP_Installer = "WINUPTP64.exe"
				# BIOS Update installer silent switch
				$Silent_Switch = "-s"			
				# Path of the BIOS installer
				$WINUTP_Install_Path = "$Extract_Folder_Path\$WINUTP_Installer"	
				# BIOS Update log name
				$WINUTP_Log_File = "winuptp.log"	
				# BIOS Update log path
				$WINUTP_Log_Path = "$Extract_Folder_Path\$WINUTP_Log_File"	
						
				Write_Log -Message_Type "INFO" -Message "Mise à jour du BIOS"	
				If(test-path $WINUTP_Install_Path)
					{
						Try
							{
								Write_Log -Message_Type "INFO" -Message "Updating BIOS update"									
								Write_Log -Message_Type "INFO" -Message "Path of the update: $Extract_Folder_Path\$WINUTP_Installer"	
								
								$Update_Process = Start-Process -FilePath $WINUTP_Installer -WorkingDirectory $Extract_Folder_Path -ArgumentList $Silent_Switch -PassThru -Wait
								If(($Update_Process.ExitCode) -eq 1) 
									{
										Write_Log -Message_Type "INFO" -Message "Checking update state in log file"																				
										If(test-path $WINUTP_Log_Path)
											{
												$Check_BIOSUpdate_Status_FromLog = ((Get-content $WINUTP_Log_Path | where-object { $_ -like "*BIOS Flash completed*"}) -ne "")		
												If($Check_BIOSUpdate_Status_FromLog -ne $null)
													{
														Write_Log -Message_Type "SUCCESS" -Message "Updating BIOS"															
														Write_Log -Message_Type "INFO" -Message "Reboot pending"	
														start-process -WindowStyle hidden powershell.exe "$WPF_Warning_Export_Folder\Restart_Computer.ps1" -Wait	
														Remove-item $BIOS_Update_Folder -Force -Recurse
														Break		
													}
												Else
													{									
														Write_Log -Message_Type "ERROR" -Message "Updating BIOS"		
														Break
													}
											}
										Else
											{
												Write_Log -Message_Type "SUCCESS" -Message "File not found: $WINUTP_Log_Path"												
											}
									}	
								Else
									{
										Write_Log -Message_Type "ERROR" -Message "Updating BIOS"	
										Break						
									}										
							}
						Catch
							{
								Write_Log -Message_Type "ERROR" -Message "Updating BIOS"	
								Break						
							}			
					}
				Else
					{
						Write_Log -Message_Type "INFO" -Message "BIOS installer not found: $WINUTP_Install_Path"						
					}
			}										
	}